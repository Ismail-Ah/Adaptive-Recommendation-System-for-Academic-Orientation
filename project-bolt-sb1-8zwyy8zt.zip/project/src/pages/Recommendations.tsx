import React, { useState } from 'react';
import { ThumbsUp, ThumbsDown, RefreshCw } from 'lucide-react';
import type { Recommendation } from '../types';

// Mock recommendation data
const mockRecommendation: Recommendation = {
  programs: ['Génie Civil', 'Médecine', 'Informatique'],
  careers: ['Ingénieur', 'Médecin', 'Développeur'],
};

function Recommendations() {
  const [recommendation, setRecommendation] = useState(mockRecommendation);
  const [loading, setLoading] = useState(false);

  const handleRefresh = async () => {
    setLoading(true);
    // TODO: Implement refresh logic
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleFeedback = (type: 'like' | 'dislike', item: string) => {
    console.log(`Feedback: ${type} for ${item}`);
    // TODO: Implement feedback logic
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Your Recommendations</h2>
            <button
              onClick={handleRefresh}
              disabled={loading}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Recommended Programs</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {recommendation.programs.map((program) => (
                  <div
                    key={program}
                    className="bg-gray-50 rounded-lg p-4 flex justify-between items-center"
                  >
                    <span className="text-lg">{program}</span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleFeedback('like', program)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-full"
                      >
                        <ThumbsUp className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleFeedback('dislike', program)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                      >
                        <ThumbsDown className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4">Career Paths</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {recommendation.careers.map((career) => (
                  <div
                    key={career}
                    className="bg-gray-50 rounded-lg p-4 flex justify-between items-center"
                  >
                    <span className="text-lg">{career}</span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleFeedback('like', career)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-full"
                      >
                        <ThumbsUp className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleFeedback('dislike', career)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                      >
                        <ThumbsDown className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Recommendations;