import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import type { User } from '../types';

const profileSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  year: z.enum(['1ère Bac', '2ème Bac']),
  interests: z.array(z.string()).min(1, 'Select at least one interest'),
  subjects: z.array(z.object({
    name: z.string(),
    grade: z.number().min(0).max(100),
  })).min(1, 'Add at least one subject'),
});

type ProfileForm = z.infer<typeof profileSchema>;

// Mock user data
const mockUser: User = {
  id: '1',
  name: 'Sara Fatima',
  year: '1ère Bac',
  interests: ['Mathématiques', 'Physique'],
  subjects: [
    { name: 'Mathématiques', grade: 85 },
    { name: 'Physique-Chimie', grade: 90 },
  ],
};

function Profile() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: mockUser,
  });

  const onSubmit = async (data: ProfileForm) => {
    console.log('Profile update:', data);
    // TODO: Implement profile update logic
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-8">
        <h2 className="text-2xl font-bold text-center mb-8">Profile Information</h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Full Name
            </label>
            <input
              type="text"
              id="name"
              {...register('name')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
            )}
          </div>

          <div>
            <label htmlFor="year" className="block text-sm font-medium text-gray-700">
              Year
            </label>
            <select
              id="year"
              {...register('year')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="1ère Bac">1ère Bac</option>
              <option value="2ème Bac">2ème Bac</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Interests
            </label>
            <div className="grid grid-cols-2 gap-4">
              {['Mathématiques', 'Physique', 'Chimie', 'Biologie', 'Informatique'].map((interest) => (
                <label key={interest} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    value={interest}
                    {...register('interests')}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">{interest}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Subjects and Grades
            </label>
            <div className="space-y-4">
              {mockUser.subjects.map((subject, index) => (
                <div key={subject.name} className="flex space-x-4">
                  <input
                    type="text"
                    value={subject.name}
                    disabled
                    className="flex-1 rounded-md border-gray-300 bg-gray-50"
                  />
                  <input
                    type="number"
                    min="0"
                    max="100"
                    {...register(`subjects.${index}.grade` as any, { valueAsNumber: true })}
                    className="w-24 rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  );
}

export default Profile;