export interface User {
  id: string;
  name: string;
  year: '1ère Bac' | '2ème Bac';
  interests: string[];
  subjects: Subject[];
}

export interface Subject {
  name: string;
  grade: number;
}

export interface Recommendation {
  programs: string[];
  careers: string[];
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  isLoading: boolean;
  error: string | null;
}

export interface AuthContextType extends AuthState {
  login: (studentId: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
}

export interface RegisterData {
  name: string;
  year: '1ère Bac' | '2ème Bac';
  interests: string[];
  subjects: Subject[];
  password: string;
}