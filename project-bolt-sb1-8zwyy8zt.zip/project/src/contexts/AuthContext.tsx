import React, { createContext, useContext, useReducer, useCallback } from 'react';
import type { AuthState, AuthContextType, RegisterData, User } from '../types';

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  isLoading: false,
  error: null,
};

type AuthAction =
  | { type: 'AUTH_START' }
  | { type: 'AUTH_SUCCESS'; payload: User }
  | { type: 'AUTH_FAILURE'; payload: string }
  | { type: 'LOGOUT' };

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case 'AUTH_START':
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    case 'AUTH_SUCCESS':
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload,
        isLoading: false,
        error: null,
      };
    case 'AUTH_FAILURE':
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        isLoading: false,
        error: action.payload,
      };
    case 'LOGOUT':
      return initialState;
    default:
      return state;
  }
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  const login = useCallback(async (studentId: string, password: string) => {
    try {
      dispatch({ type: 'AUTH_START' });
      // TODO: Implement actual login API call
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      // Simulate successful login
      const mockUser: User = {
        id: studentId,
        name: 'Sara Fatima',
        year: '1ère Bac',
        interests: ['Mathématiques', 'Physique'],
        subjects: [
          { name: 'Mathématiques', grade: 85 },
          { name: 'Physique-Chimie', grade: 90 },
        ],
      };
      
      dispatch({ type: 'AUTH_SUCCESS', payload: mockUser });
    } catch (error) {
      dispatch({ type: 'AUTH_FAILURE', payload: 'Invalid credentials' });
      throw error;
    }
  }, []);

  const register = useCallback(async (data: RegisterData) => {
    try {
      dispatch({ type: 'AUTH_START' });
      // TODO: Implement actual registration API call
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      // Simulate successful registration
      const mockUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: data.name,
        year: data.year,
        interests: data.interests,
        subjects: data.subjects,
      };
      
      dispatch({ type: 'AUTH_SUCCESS', payload: mockUser });
    } catch (error) {
      dispatch({ type: 'AUTH_FAILURE', payload: 'Registration failed' });
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      // TODO: Implement actual logout API call
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
      dispatch({ type: 'LOGOUT' });
    } catch (error) {
      console.error('Logout error:', error);
    }
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}